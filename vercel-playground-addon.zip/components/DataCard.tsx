export default function DataCard({
  title,
  data,
  renderType,
}: {
  title: string;
  data: { time: string; price: string };
  renderType: string;
}) {
  return (
    <div className="p-6 border rounded-xl shadow-sm bg-white space-y-3">
      <h2 className="text-2xl font-bold">{title}</h2>
      <p className="text-slate-600">Rendered via {renderType}</p>
      <div className="bg-slate-50 p-4 rounded-md border">
        <p>
          <strong>Current Bitcoin Price:</strong> ${data.price}
        </p>
        <p className="text-xs text-slate-500">Rendered at: {data.time}</p>
      </div>
    </div>
  );
}
