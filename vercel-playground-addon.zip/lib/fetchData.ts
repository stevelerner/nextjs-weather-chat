export async function fetchData() {
  const res = await fetch("https://api.coindesk.com/v1/bpi/currentprice.json", {
    next: { revalidate: 0 },
  });
  const data = await res.json();
  return {
    time: new Date().toISOString(),
    price: data.bpi?.USD?.rate || "N/A",
  };
}
